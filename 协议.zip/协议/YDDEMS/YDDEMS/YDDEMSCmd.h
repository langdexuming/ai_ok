#pragma once
#include <StdCmdBase.h>

class  CYDDEMSCmd;

DECLARE_COMMAND_STRUCT(CYDDEMSCmd)

class CYDDEMSCmd  :public CStdCmdBase
{
public:
	CYDDEMSCmd(DWORD dwID);
	~CYDDEMSCmd(void);
public:

	BOOL PackCmdWrite10( BYTE byAddr, BYTE byFC, WORD wStartAddr, WORD wAddrNum,int iDataLen, BYTE * arrData, BYTE * pBuf, int &nSize);

	//��һ·���߻�·��������(����)
	BOOL PackCmdFirstDataFloat(ChannelList & InputChannelList, ChannelList & globalParam, BYTE * pBuf, int & nSize);
	BOOL UnPackCmdFirstDataFloat(BYTE * pBuf, int nSize,  ChannelList & OutputChannelList, ChannelList & globalParam);

	//�ڶ�·���߻�·��������(����)
	BOOL PackCmdSecondDataFloat(ChannelList & InputChannelList, ChannelList & globalParam, BYTE * pBuf, int & nSize);
	BOOL UnPackCmdSecondDataFloat(BYTE * pBuf, int nSize,  ChannelList & OutputChannelList, ChannelList & globalParam);
	
	//������·���ֵ�������(����)
	BOOL PackCmdPowerPartData1_15(ChannelList & InputChannelList, ChannelList & globalParam, BYTE * pBuf, int & nSize);
	BOOL UnPackCmdPowerPartData1_15(BYTE * pBuf, int nSize,  ChannelList & OutputChannelList, ChannelList & globalParam);

	BOOL PackCmdPowerPartData16_30(ChannelList & InputChannelList, ChannelList & globalParam, BYTE * pBuf, int & nSize);
	BOOL UnPackCmdPowerPartData16_30(BYTE * pBuf, int nSize,  ChannelList & OutputChannelList, ChannelList & globalParam);

	BOOL PackCmdPowerPartData31_45(ChannelList & InputChannelList, ChannelList & globalParam, BYTE * pBuf, int & nSize);
	BOOL UnPackCmdPowerPartData31_45(BYTE * pBuf, int nSize,  ChannelList & OutputChannelList, ChannelList & globalParam);

	BOOL PackCmdPowerPartData46_60(ChannelList & InputChannelList, ChannelList & globalParam, BYTE * pBuf, int & nSize);
	BOOL UnPackCmdPowerPartData46_60(BYTE * pBuf, int nSize,  ChannelList & OutputChannelList, ChannelList & globalParam);

	BOOL PackCmdPowerPartData61_75(ChannelList & InputChannelList, ChannelList & globalParam, BYTE * pBuf, int & nSize);
	BOOL UnPackCmdPowerPartData61_75(BYTE * pBuf, int nSize,  ChannelList & OutputChannelList, ChannelList & globalParam);

	BOOL PackCmdPowerPartData76_90(ChannelList & InputChannelList, ChannelList & globalParam, BYTE * pBuf, int & nSize);
	BOOL UnPackCmdPowerPartData76_90(BYTE * pBuf, int nSize,  ChannelList & OutputChannelList, ChannelList & globalParam);

	BOOL PackCmdPowerPartData91_105(ChannelList & InputChannelList, ChannelList & globalParam, BYTE * pBuf, int & nSize);
	BOOL UnPackCmdPowerPartData91_105(BYTE * pBuf, int nSize,  ChannelList & OutputChannelList, ChannelList & globalParam);

	BOOL PackCmdPowerPartData106_120(ChannelList & InputChannelList, ChannelList & globalParam, BYTE * pBuf, int & nSize);
	BOOL UnPackCmdPowerPartData106_120(BYTE * pBuf, int nSize,  ChannelList & OutputChannelList, ChannelList & globalParam);

	BOOL PackCmdPowerPartData121_135(ChannelList & InputChannelList, ChannelList & globalParam, BYTE * pBuf, int & nSize);
	BOOL UnPackCmdPowerPartData121_135(BYTE * pBuf, int nSize,  ChannelList & OutputChannelList, ChannelList & globalParam);

	BOOL PackCmdPowerPartData136_144(ChannelList & InputChannelList, ChannelList & globalParam, BYTE * pBuf, int & nSize);
	BOOL UnPackCmdPowerPartData136_144(BYTE * pBuf, int nSize,  ChannelList & OutputChannelList, ChannelList & globalParam);

	BOOL PackCmdAlarmData(ChannelList & InputChannelList, ChannelList & globalParam, BYTE * pBuf, int & nSize);
	BOOL UnPackCmdAlarmData(BYTE * pBuf, int nSize,  ChannelList & OutputChannelList, ChannelList & globalParam);

	BOOL PackCmdOnOffAlarmData(ChannelList & InputChannelList, ChannelList & globalParam, BYTE * pBuf, int & nSize);
	BOOL UnPackCmdOnOffAlarmData(BYTE * pBuf, int nSize,  ChannelList & OutputChannelList, ChannelList & globalParam);

	BOOL PackCmdOnOffStatusData(ChannelList & InputChannelList, ChannelList & globalParam, BYTE * pBuf, int & nSize);
	BOOL UnPackCmdOnOffStatusData(BYTE * pBuf, int nSize,  ChannelList & OutputChannelList, ChannelList & globalParam);

	BOOL PackCmdTemp1_72(ChannelList & InputChannelList, ChannelList & globalParam, BYTE * pBuf, int & nSize);
	BOOL UnPackCmdTemp1_72(BYTE * pBuf, int nSize,  ChannelList & OutputChannelList, ChannelList & globalParam);

	BOOL PackCmdTemp73_144(ChannelList & InputChannelList, ChannelList & globalParam, BYTE * pBuf, int & nSize);
	BOOL UnPackCmdTemp73_144(BYTE * pBuf, int nSize,  ChannelList & OutputChannelList, ChannelList & globalParam);

	BOOL PackCmdCurrentAlarmData(ChannelList & InputChannelList, ChannelList & globalParam, BYTE * pBuf, int & nSize);
	BOOL UnPackCmdCurrentAlarmData(BYTE * pBuf, int nSize,  ChannelList & OutputChannelList, ChannelList & globalParam);

	BOOL PackCmdCurrentAlarmSetting(ChannelList & InputChannelList, ChannelList & globalParam, BYTE * pBuf, int & nSize);
	BOOL UnPackCmdCurrentAlarmSetting(BYTE * pBuf, int nSize,  ChannelList & OutputChannelList, ChannelList & globalParam);

	BOOL PackCmdSetData(ChannelList & InputChannelList, ChannelList & globalParam, BYTE * pBuf, int & nSize);
	BOOL UnPackCmdSetData(BYTE * pBuf, int nSize,  ChannelList & OutputChannelList, ChannelList & globalParam);

	BOOL PackCmdFirstDataHarmonic(ChannelList & InputChannelList, ChannelList & globalParam, BYTE * pBuf, int & nSize);
	BOOL UnPackCmdFirstDataHarmonic(BYTE * pBuf, int nSize,  ChannelList & OutputChannelList, ChannelList & globalParam);

	BOOL PackCmdSecondDataHarmonic(ChannelList & InputChannelList, ChannelList & globalParam, BYTE * pBuf, int & nSize);
	BOOL UnPackCmdSecondDataHarmonic(BYTE * pBuf, int nSize,  ChannelList & OutputChannelList, ChannelList & globalParam);

	BOOL PackCmdPowerPartDataALL(ChannelList & InputChannelList, ChannelList & globalParam, BYTE * pBuf, int & nSize);
	BOOL UnPackCmdPowerPartDataALL(BYTE * pBuf, int nSize,  ChannelList & OutputChannelList, ChannelList & globalParam);

	BOOL PackCmdFirstPower2(ChannelList & InputChannelList, ChannelList & globalParam, BYTE * pBuf, int & nSize);
	BOOL UnPackCmdFirstPower2(BYTE * pBuf, int nSize,  ChannelList & OutputChannelList, ChannelList & globalParam);

	BOOL PackCmdSecondPower2(ChannelList & InputChannelList, ChannelList & globalParam, BYTE * pBuf, int & nSize);
	BOOL UnPackCmdSecondPower2(BYTE * pBuf, int nSize,  ChannelList & OutputChannelList, ChannelList & globalParam);

	BOOL PackCmdFirstFundamental(ChannelList & InputChannelList, ChannelList & globalParam, BYTE * pBuf, int & nSize);
	BOOL UnPackCmdFirstFundamental(BYTE * pBuf, int nSize,  ChannelList & OutputChannelList, ChannelList & globalParam);

	BOOL PackCmdSecondFundamental(ChannelList & InputChannelList, ChannelList & globalParam, BYTE * pBuf, int & nSize);
	BOOL UnPackCmdSecondFundamental(BYTE * pBuf, int nSize,  ChannelList & OutputChannelList, ChannelList & globalParam);

	BOOL PackCmdOnOffStatusData2(ChannelList & InputChannelList, ChannelList & globalParam, BYTE * pBuf, int & nSize);
	BOOL UnPackCmdOnOffStatusData2(BYTE * pBuf, int nSize,  ChannelList & OutputChannelList, ChannelList & globalParam);

public:
	BYTE m_byNum;
	float m_totalPower;

};
