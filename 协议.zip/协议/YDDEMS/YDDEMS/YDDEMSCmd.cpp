//#include "StdAfx.h"
#include "YDDEMSCmd.h"
#include <ModbusCmd.h>

IMPLEMENT_COMMAND_STRUCT(CYDDEMSCmd)

CYDDEMSCmd::CYDDEMSCmd(DWORD dwID):CStdCmdBase(dwID) 
{
	m_byAddrCode = 0x01;
	m_byNum = 0;
	m_totalPower=0;
}

CYDDEMSCmd::~CYDDEMSCmd(void)
{

}

BOOL CYDDEMSCmd::PackCmdWrite10( BYTE byAddr, BYTE byFC, WORD wStartAddr, WORD wAddrNum,int iDataLen, BYTE * arrData, BYTE * pBuf, int &nSize)
{
	BYTE *pAt =pBuf;

	//��ַ
	pAt[0] = byAddr;

	//������
	pAt[1] = byFC;

	//��ʼ��ַ
	pAt[2] = wStartAddr/0x100;	
	pAt[3] = wStartAddr%0x100;

	//�Ĵ������� ��λ��ǰ
	pAt[4] = wAddrNum/0x100;
	pAt[5] = wAddrNum%0x100;
	//�������ֽ���
	pAt[6]=iDataLen;
	//��������
	for(int i=0;i<iDataLen;i++)
	{
		pAt[7+i]=arrData[i];
	}

	//����CRC16У����
	int nDataLen = 7+iDataLen;
	WORD  wCode = CModbusCmd::GetCRC16(pAt, nDataLen);

	//���ֽ���ǰ

	pAt[7+iDataLen] = wCode % 0x100;
	pAt[8+iDataLen] = wCode / 0x100;

	nSize = 9+iDataLen;
	return TRUE;
}

//��һ·���߻�·��������(����)
BOOL CYDDEMSCmd::PackCmdFirstDataFloat(ChannelList & InputChannelList, ChannelList & globalParam, BYTE * pBuf, int & nSize)
{
	return CModbusCmd::PackCmd(m_byAddrCode,0x03, 1024, 120,pBuf,nSize);
}
BOOL CYDDEMSCmd::UnPackCmdFirstDataFloat(BYTE * pBuf, int nSize,  ChannelList & OutputChannelList, ChannelList & globalParam)
{
	BYTE byAddr,byFC;
	BYTE byDataLen = 0;

	//���CRC16У��λ �� nSize ����
	if (!CModbusCmd::UnpackCmd(pBuf,nSize,byAddr,byFC,byDataLen))
	{
		return FALSE;
	}

	if (byAddr != m_byAddrCode)
	{
		return FALSE;
	}

	//��鹦����
	if(byFC != 0x03)
	{
		return FALSE;
	}

	if (byDataLen != 240)
	{
	}

	CSafeReadBufferAuto  safeBuf(pBuf+3, nSize);    //��д
	DECLARE_UNPACK_VAR;

	float fValue;
	DWORD dwValue=0;
	WORD wValueL=0;
	WORD wValueH=0;
	int i=0;

	float fValABC[3] = {0};

	for(i=0;i<60;i++)
	{
		safeBuf.ReadWord(wValueL,HighFirst);
		safeBuf.ReadWord(wValueH,HighFirst);
		dwValue = (wValueH<<16)+wValueL;
		memcpy(&fValue,&dwValue,sizeof(float));
		OUTPUT_VALUE(1001+i,fValue);

		if (i<3)
		{
			fValABC[i] = fValue;
		}

		if ((1001+i) == 1041)
		{
			m_totalPower = fValue;
		}
	}

	BYTE byAlarmTD = 0;
	BYTE byAlarmQX1 = 0;
	BYTE byAlarmQX2 = 0;

	int nQXtotal = 0;

	for (int i=0;i<3;i++)
	{
		if (fValABC[i] < 100)
		{
			nQXtotal ++;
		}
	}

	if (nQXtotal == 1)
	{
		byAlarmQX1 = 1;
	}

	else if (nQXtotal == 2)
	{
		byAlarmQX2 = 1;
	}

	else if (nQXtotal == 3)
	{
		byAlarmTD = 1;
	}

	OUTPUT_VALUE(10001,byAlarmTD);
	OUTPUT_VALUE(10002,byAlarmQX1);
	OUTPUT_VALUE(10003,byAlarmQX2);

	return TRUE;

}

//�ڶ�·���߻�·��������(����)
BOOL CYDDEMSCmd::PackCmdSecondDataFloat(ChannelList & InputChannelList, ChannelList & globalParam, BYTE * pBuf, int & nSize)
{
	return CModbusCmd::PackCmd(m_byAddrCode,0x03, 1536, 120,pBuf,nSize);
}
BOOL CYDDEMSCmd::UnPackCmdSecondDataFloat(BYTE * pBuf, int nSize,  ChannelList & OutputChannelList, ChannelList & globalParam)
{
	BYTE byAddr,byFC;
	BYTE byDataLen = 0;

	//���CRC16У��λ �� nSize ����
	if (!CModbusCmd::UnpackCmd(pBuf,nSize,byAddr,byFC,byDataLen))
	{
		return FALSE;
	}

	if (byAddr != m_byAddrCode)
	{
		return FALSE;
	}

	//��鹦����
	if(byFC != 0x03)
	{
		return FALSE;
	}

	if (byDataLen != 240)
	{
	}

	CSafeReadBufferAuto  safeBuf(pBuf+3, nSize);    //��д
	DECLARE_UNPACK_VAR;

	float fValue;
	DWORD dwValue=0;
	WORD wValueL=0;
	WORD wValueH=0;
	int i=0;

	float fValABC[3] = {0};

	for(i=0;i<60;i++)
	{
		safeBuf.ReadWord(wValueL,HighFirst);
		safeBuf.ReadWord(wValueH,HighFirst);
		dwValue = (wValueH<<16)+wValueL;
		memcpy(&fValue,&dwValue,sizeof(float));
		OUTPUT_VALUE(2001+i,fValue);

		if (i<3)
		{
			fValABC[i] = fValue;
		}

		if ((2001+i) == 2041)
		{
			m_totalPower += fValue;
		}
	}

	OUTPUT_VALUE(60000,m_totalPower);
	BYTE byAlarmTD = 0;
	BYTE byAlarmQX1 = 0;
	BYTE byAlarmQX2 = 0;

	int nQXtotal = 0;

	for (int i=0;i<3;i++)
	{
		if (fValABC[i] < 100)
		{
			nQXtotal ++;
		}
	}

	if (nQXtotal == 1)
	{
		byAlarmQX1 = 1;
	}

	else if (nQXtotal == 2)
	{
		byAlarmQX2 = 1;
	}

	else if (nQXtotal == 3)
	{
		byAlarmTD = 1;
	}

	OUTPUT_VALUE(20001,byAlarmTD);
	OUTPUT_VALUE(20002,byAlarmQX1);
	OUTPUT_VALUE(20003,byAlarmQX2);

	return TRUE;
}

//������·���ֵ�������(����)
BOOL CYDDEMSCmd::PackCmdPowerPartData1_15(ChannelList & InputChannelList, ChannelList & globalParam, BYTE * pBuf, int & nSize)
{
	return CModbusCmd::PackCmd(m_byAddrCode,0x03, 28672, 120,pBuf,nSize);
}
BOOL CYDDEMSCmd::UnPackCmdPowerPartData1_15(BYTE * pBuf, int nSize,  ChannelList & OutputChannelList, ChannelList & globalParam)
{
	BYTE byAddr,byFC;
	BYTE byDataLen = 0;

	//���CRC16У��λ �� nSize ����
	if (!CModbusCmd::UnpackCmd(pBuf,nSize,byAddr,byFC,byDataLen))
	{
		return FALSE;
	}

	if (byAddr != m_byAddrCode)
	{
		return FALSE;
	}

	//��鹦����
	if(byFC != 0x03)
	{
		return FALSE;
	}

	if (byDataLen != 240)
	{
	}

	CSafeReadBufferAuto  safeBuf(pBuf+3, nSize);    //��д
	DECLARE_UNPACK_VAR;

	float fValue;
	DWORD dwValue=0;
	WORD wValueL=0;
	WORD wValueH=0;
	int i=0;

	for(i=0;i<60;i++)
	{
		safeBuf.ReadWord(wValueL,HighFirst);
		safeBuf.ReadWord(wValueH,HighFirst);
		dwValue = (wValueH<<16)+wValueL;
		memcpy(&fValue,&dwValue,sizeof(float));
		
		OUTPUT_VALUE(3001 + i,fValue);
	}

	return TRUE;
}

BOOL CYDDEMSCmd::PackCmdPowerPartData16_30(ChannelList & InputChannelList, ChannelList & globalParam, BYTE * pBuf, int & nSize)
{
	return CModbusCmd::PackCmd(m_byAddrCode,0x03, 28672+120, 120,pBuf,nSize);
}
BOOL CYDDEMSCmd::UnPackCmdPowerPartData16_30(BYTE * pBuf, int nSize,  ChannelList & OutputChannelList, ChannelList & globalParam)
{
	BYTE byAddr,byFC;
	BYTE byDataLen = 0;

	//���CRC16У��λ �� nSize ����
	if (!CModbusCmd::UnpackCmd(pBuf,nSize,byAddr,byFC,byDataLen))
	{
		return FALSE;
	}

	if (byAddr != m_byAddrCode)
	{
		return FALSE;
	}

	//��鹦����
	if(byFC != 0x03)
	{
		return FALSE;
	}

	if (byDataLen != 240)
	{
	}

	CSafeReadBufferAuto  safeBuf(pBuf+3, nSize);    //��д
	DECLARE_UNPACK_VAR;

	float fValue;
	DWORD dwValue=0;
	WORD wValueL=0;
	WORD wValueH=0;
	int i=0;

	for(i=0;i<60;i++)
	{
		safeBuf.ReadWord(wValueL,HighFirst);
		safeBuf.ReadWord(wValueH,HighFirst);
		dwValue = (wValueH<<16)+wValueL;
		memcpy(&fValue,&dwValue,sizeof(float));

		OUTPUT_VALUE(3001+ 60 + i,fValue);
	}

	return TRUE;
}

BOOL CYDDEMSCmd::PackCmdPowerPartData31_45(ChannelList & InputChannelList, ChannelList & globalParam, BYTE * pBuf, int & nSize)
{
	return CModbusCmd::PackCmd(m_byAddrCode,0x03, 28672+120*2, 120,pBuf,nSize);
}
BOOL CYDDEMSCmd::UnPackCmdPowerPartData31_45(BYTE * pBuf, int nSize,  ChannelList & OutputChannelList, ChannelList & globalParam)
{
	BYTE byAddr,byFC;
	BYTE byDataLen = 0;

	//���CRC16У��λ �� nSize ����
	if (!CModbusCmd::UnpackCmd(pBuf,nSize,byAddr,byFC,byDataLen))
	{
		return FALSE;
	}

	if (byAddr != m_byAddrCode)
	{
		return FALSE;
	}

	//��鹦����
	if(byFC != 0x03)
	{
		return FALSE;
	}

	if (byDataLen != 240)
	{
	}

	CSafeReadBufferAuto  safeBuf(pBuf+3, nSize);    //��д
	DECLARE_UNPACK_VAR;

	float fValue;
	DWORD dwValue=0;
	WORD wValueL=0;
	WORD wValueH=0;
	int i=0;

	for(i=0;i<60;i++)
	{
		safeBuf.ReadWord(wValueL,HighFirst);
		safeBuf.ReadWord(wValueH,HighFirst);
		dwValue = (wValueH<<16)+wValueL;
		memcpy(&fValue,&dwValue,sizeof(float));

		OUTPUT_VALUE(3001+ 60*2 + i,fValue);
	}

	return TRUE;
}

BOOL CYDDEMSCmd::PackCmdPowerPartData46_60(ChannelList & InputChannelList, ChannelList & globalParam, BYTE * pBuf, int & nSize)
{
	return CModbusCmd::PackCmd(m_byAddrCode,0x03, 28672+120*3, 120,pBuf,nSize);
}
BOOL CYDDEMSCmd::UnPackCmdPowerPartData46_60(BYTE * pBuf, int nSize,  ChannelList & OutputChannelList, ChannelList & globalParam)
{
	BYTE byAddr,byFC;
	BYTE byDataLen = 0;

	//���CRC16У��λ �� nSize ����
	if (!CModbusCmd::UnpackCmd(pBuf,nSize,byAddr,byFC,byDataLen))
	{
		return FALSE;
	}

	if (byAddr != m_byAddrCode)
	{
		return FALSE;
	}

	//��鹦����
	if(byFC != 0x03)
	{
		return FALSE;
	}

	if (byDataLen != 240)
	{
	}

	CSafeReadBufferAuto  safeBuf(pBuf+3, nSize);    //��д
	DECLARE_UNPACK_VAR;

	float fValue;
	DWORD dwValue=0;
	WORD wValueL=0;
	WORD wValueH=0;
	int i=0;

	for(i=0;i<60;i++)
	{
		safeBuf.ReadWord(wValueL,HighFirst);
		safeBuf.ReadWord(wValueH,HighFirst);
		dwValue = (wValueH<<16)+wValueL;
		memcpy(&fValue,&dwValue,sizeof(float));

		OUTPUT_VALUE(3001+ 60*3 + i,fValue);
	}

	return TRUE;
}

BOOL CYDDEMSCmd::PackCmdPowerPartData61_75(ChannelList & InputChannelList, ChannelList & globalParam, BYTE * pBuf, int & nSize)
{
	return CModbusCmd::PackCmd(m_byAddrCode,0x03, 28672+120*4, 120,pBuf,nSize);
}
BOOL CYDDEMSCmd::UnPackCmdPowerPartData61_75(BYTE * pBuf, int nSize,  ChannelList & OutputChannelList, ChannelList & globalParam)
{
	BYTE byAddr,byFC;
	BYTE byDataLen = 0;

	//���CRC16У��λ �� nSize ����
	if (!CModbusCmd::UnpackCmd(pBuf,nSize,byAddr,byFC,byDataLen))
	{
		return FALSE;
	}

	if (byAddr != m_byAddrCode)
	{
		return FALSE;
	}

	//��鹦����
	if(byFC != 0x03)
	{
		return FALSE;
	}

	if (byDataLen != 240)
	{
	}

	CSafeReadBufferAuto  safeBuf(pBuf+3, nSize);    //��д
	DECLARE_UNPACK_VAR;

	float fValue;
	DWORD dwValue=0;
	WORD wValueL=0;
	WORD wValueH=0;
	int i=0;

	for(i=0;i<60;i++)
	{
		safeBuf.ReadWord(wValueL,HighFirst);
		safeBuf.ReadWord(wValueH,HighFirst);
		dwValue = (wValueH<<16)+wValueL;
		memcpy(&fValue,&dwValue,sizeof(float));

		OUTPUT_VALUE(3001+ 60*4 + i,fValue);
	}

	return TRUE;
}

BOOL CYDDEMSCmd::PackCmdPowerPartData76_90(ChannelList & InputChannelList, ChannelList & globalParam, BYTE * pBuf, int & nSize)
{
	return CModbusCmd::PackCmd(m_byAddrCode,0x03, 28672+120*5, 120,pBuf,nSize);
}
BOOL CYDDEMSCmd::UnPackCmdPowerPartData76_90(BYTE * pBuf, int nSize,  ChannelList & OutputChannelList, ChannelList & globalParam)
{
	BYTE byAddr,byFC;
	BYTE byDataLen = 0;

	//���CRC16У��λ �� nSize ����
	if (!CModbusCmd::UnpackCmd(pBuf,nSize,byAddr,byFC,byDataLen))
	{
		return FALSE;
	}

	if (byAddr != m_byAddrCode)
	{
		return FALSE;
	}

	//��鹦����
	if(byFC != 0x03)
	{
		return FALSE;
	}

	if (byDataLen != 240)
	{
	}

	CSafeReadBufferAuto  safeBuf(pBuf+3, nSize);    //��д
	DECLARE_UNPACK_VAR;

	float fValue;
	DWORD dwValue=0;
	WORD wValueL=0;
	WORD wValueH=0;
	int i=0;

	for(i=0;i<60;i++)
	{
		safeBuf.ReadWord(wValueL,HighFirst);
		safeBuf.ReadWord(wValueH,HighFirst);
		dwValue = (wValueH<<16)+wValueL;
		memcpy(&fValue,&dwValue,sizeof(float));

		OUTPUT_VALUE(3001+ 60*5 + i,fValue);
	}

	return TRUE;
}

BOOL CYDDEMSCmd::PackCmdPowerPartData91_105(ChannelList & InputChannelList, ChannelList & globalParam, BYTE * pBuf, int & nSize)
{
	return CModbusCmd::PackCmd(m_byAddrCode,0x03, 28672+120*6, 120,pBuf,nSize);
}
BOOL CYDDEMSCmd::UnPackCmdPowerPartData91_105(BYTE * pBuf, int nSize,  ChannelList & OutputChannelList, ChannelList & globalParam)
{
	BYTE byAddr,byFC;
	BYTE byDataLen = 0;

	//���CRC16У��λ �� nSize ����
	if (!CModbusCmd::UnpackCmd(pBuf,nSize,byAddr,byFC,byDataLen))
	{
		return FALSE;
	}

	if (byAddr != m_byAddrCode)
	{
		return FALSE;
	}

	//��鹦����
	if(byFC != 0x03)
	{
		return FALSE;
	}

	if (byDataLen != 240)
	{
	}

	CSafeReadBufferAuto  safeBuf(pBuf+3, nSize);    //��д
	DECLARE_UNPACK_VAR;

	float fValue;
	DWORD dwValue=0;
	WORD wValueL=0;
	WORD wValueH=0;
	int i=0;

	for(i=0;i<60;i++)
	{
		safeBuf.ReadWord(wValueL,HighFirst);
		safeBuf.ReadWord(wValueH,HighFirst);
		dwValue = (wValueH<<16)+wValueL;
		memcpy(&fValue,&dwValue,sizeof(float));

		OUTPUT_VALUE(3001+ 60*6 + i,fValue);
	}

	return TRUE;
}

BOOL CYDDEMSCmd::PackCmdPowerPartData106_120(ChannelList & InputChannelList, ChannelList & globalParam, BYTE * pBuf, int & nSize)
{
	return CModbusCmd::PackCmd(m_byAddrCode,0x03, 28672+120*7, 120,pBuf,nSize);
}
BOOL CYDDEMSCmd::UnPackCmdPowerPartData106_120(BYTE * pBuf, int nSize,  ChannelList & OutputChannelList, ChannelList & globalParam)
{
	BYTE byAddr,byFC;
	BYTE byDataLen = 0;

	//���CRC16У��λ �� nSize ����
	if (!CModbusCmd::UnpackCmd(pBuf,nSize,byAddr,byFC,byDataLen))
	{
		return FALSE;
	}

	if (byAddr != m_byAddrCode)
	{
		return FALSE;
	}

	//��鹦����
	if(byFC != 0x03)
	{
		return FALSE;
	}

	if (byDataLen != 240)
	{
	}

	CSafeReadBufferAuto  safeBuf(pBuf+3, nSize);    //��д
	DECLARE_UNPACK_VAR;

	float fValue;
	DWORD dwValue=0;
	WORD wValueL=0;
	WORD wValueH=0;
	int i=0;

	for(i=0;i<60;i++)
	{
		safeBuf.ReadWord(wValueL,HighFirst);
		safeBuf.ReadWord(wValueH,HighFirst);
		dwValue = (wValueH<<16)+wValueL;
		memcpy(&fValue,&dwValue,sizeof(float));

		OUTPUT_VALUE(3001+ 60*7 + i,fValue);
	}

	return TRUE;

}

BOOL CYDDEMSCmd::PackCmdPowerPartData121_135(ChannelList & InputChannelList, ChannelList & globalParam, BYTE * pBuf, int & nSize)
{
	return CModbusCmd::PackCmd(m_byAddrCode,0x03, 28672+120*8, 120,pBuf,nSize);
}
BOOL CYDDEMSCmd::UnPackCmdPowerPartData121_135(BYTE * pBuf, int nSize,  ChannelList & OutputChannelList, ChannelList & globalParam)
{
	BYTE byAddr,byFC;
	BYTE byDataLen = 0;

	//���CRC16У��λ �� nSize ����
	if (!CModbusCmd::UnpackCmd(pBuf,nSize,byAddr,byFC,byDataLen))
	{
		return FALSE;
	}

	if (byAddr != m_byAddrCode)
	{
		return FALSE;
	}

	//��鹦����
	if(byFC != 0x03)
	{
		return FALSE;
	}

	if (byDataLen != 240)
	{
	}

	CSafeReadBufferAuto  safeBuf(pBuf+3, nSize);    //��д
	DECLARE_UNPACK_VAR;

	float fValue;
	DWORD dwValue=0;
	WORD wValueL=0;
	WORD wValueH=0;
	int i=0;

	for(i=0;i<60;i++)
	{
		safeBuf.ReadWord(wValueL,HighFirst);
		safeBuf.ReadWord(wValueH,HighFirst);
		dwValue = (wValueH<<16)+wValueL;
		memcpy(&fValue,&dwValue,sizeof(float));

		OUTPUT_VALUE(3001+ 60*8 + i,fValue);
	}

	return TRUE;

}

BOOL CYDDEMSCmd::PackCmdPowerPartData136_144(ChannelList & InputChannelList, ChannelList & globalParam, BYTE * pBuf, int & nSize)
{
	return CModbusCmd::PackCmd(m_byAddrCode,0x03, 28672+120*9, 72,pBuf,nSize);
}
BOOL CYDDEMSCmd::UnPackCmdPowerPartData136_144(BYTE * pBuf, int nSize,  ChannelList & OutputChannelList, ChannelList & globalParam)
{
	BYTE byAddr,byFC;
	BYTE byDataLen = 0;

	//���CRC16У��λ �� nSize ����
	if (!CModbusCmd::UnpackCmd(pBuf,nSize,byAddr,byFC,byDataLen))
	{
		return FALSE;
	}

	if (byAddr != m_byAddrCode)
	{
		return FALSE;
	}

	//��鹦����
	if(byFC != 0x03)
	{
		return FALSE;
	}

	if (byDataLen != 144)
	{
	}

	CSafeReadBufferAuto  safeBuf(pBuf+3, nSize);    //��д
	DECLARE_UNPACK_VAR;

	float fValue;
	DWORD dwValue=0;
	WORD wValueL=0;
	WORD wValueH=0;
	int i=0;

	for(i=0;i<36;i++)
	{
		safeBuf.ReadWord(wValueL,HighFirst);
		safeBuf.ReadWord(wValueH,HighFirst);
		dwValue = (wValueH<<16)+wValueL;
		memcpy(&fValue,&dwValue,sizeof(float));

		OUTPUT_VALUE(3001+ 60*9 + i,fValue);
	}

	return TRUE;
}

BOOL CYDDEMSCmd::PackCmdAlarmData(ChannelList & InputChannelList, ChannelList & globalParam, BYTE * pBuf, int & nSize)
{
	return CModbusCmd::PackCmd(m_byAddrCode,0x03, 49152, 14,pBuf,nSize);
}
BOOL CYDDEMSCmd::UnPackCmdAlarmData(BYTE * pBuf, int nSize,  ChannelList & OutputChannelList, ChannelList & globalParam)
{
	BYTE byAddr,byFC;
	BYTE byDataLen = 0;

	//���CRC16У��λ �� nSize ����
	if (!CModbusCmd::UnpackCmd(pBuf,nSize,byAddr,byFC,byDataLen))
	{
		return FALSE;
	}

	if (byAddr != m_byAddrCode)
	{
		return FALSE;
	}

	//��鹦����
	if(byFC != 0x03)
	{
		return FALSE;
	}

	if (byDataLen != 28)
	{
	}

	CSafeReadBufferAuto  safeBuf(pBuf+3, nSize);    //��д
	DECLARE_UNPACK_VAR;

	WORD	wValue  = 0;
	BYTE	byValue = 0;

	safeBuf.ReadWord(wValue,HighFirst);
	for (int i=0;i<=4;i++)
	{
		byValue = GETBIT(wValue,i);
		OUTPUT_VALUE(4000 + i,byValue);
	}

	for (int i = 0; i < 5; i++)
	{
		safeBuf.ReadWord(wValue,HighFirst);
		for (int j = 0; j < 16; j++)
		{
			byValue = GETBIT(wValue,j);
			OUTPUT_VALUE(4020 + i*20 + j,byValue);
		}
	}
	
	safeBuf.ReadWord(wValue,HighFirst);
	for (int i=0;i<=11;i++)
	{
		byValue = GETBIT(wValue,i);
		OUTPUT_VALUE(4160 + i,byValue);
	}

	safeBuf.JumpBack(1*2);

	for (int i = 0; i < 5; i++)
	{
		safeBuf.ReadWord(wValue,HighFirst);
		for (int j = 0; j < 16; j++)
		{
			byValue = GETBIT(wValue,j);
			OUTPUT_VALUE(4200 + i*20 + j,byValue);
		}
	}

	safeBuf.ReadWord(wValue,HighFirst);
	for (int i=0;i<=11;i++)
	{
		byValue = GETBIT(wValue,i);
		OUTPUT_VALUE(4330 + i,byValue);
	}

	return TRUE;
}
//���ع���
BOOL CYDDEMSCmd::PackCmdOnOffAlarmData(ChannelList & InputChannelList, ChannelList & globalParam, BYTE * pBuf, int & nSize)
{
	return CModbusCmd::PackCmd(m_byAddrCode,0x03, 49166, 21,pBuf,nSize);
}
BOOL CYDDEMSCmd::UnPackCmdOnOffAlarmData(BYTE * pBuf, int nSize,  ChannelList & OutputChannelList, ChannelList & globalParam)
{
	BYTE byAddr,byFC;
	BYTE byDataLen = 0;

	//���CRC16У��λ �� nSize ����
	if (!CModbusCmd::UnpackCmd(pBuf,nSize,byAddr,byFC,byDataLen))
	{
		return FALSE;
	}

	if (byAddr != m_byAddrCode)
	{
		return FALSE;
	}

	//��鹦����
	if(byFC != 0x03)
	{
		return FALSE;
	}

	if (byDataLen != 21*2)
	{
	}

	CSafeReadBufferAuto  safeBuf(pBuf+3, nSize);    //��д
	DECLARE_UNPACK_VAR;

	WORD	wValue  = 0;
	BYTE	byValue = 0;

	safeBuf.ReadWord(wValue,HighFirst);
	for (int i = 0; i < 12; i++)
	{
		byValue = GETBIT(wValue,i);
		OUTPUT_VALUE(4500+i,byValue);
	}

	safeBuf.ReadWord(wValue,HighFirst);
	for (int i = 0; i < 12; i++)
	{
		byValue = GETBIT(wValue,i);
		OUTPUT_VALUE(4600+i,byValue);
	}

	safeBuf.ReadWord(wValue,HighFirst);
	for (int i = 0; i < 11; i++)
	{
		byValue = GETBIT(wValue,i);
		OUTPUT_VALUE(4700+i,byValue);
	}

	for (int i=0;i<9;i++)
	{
		safeBuf.ReadWord(wValue,HighFirst);
		for (int j=0;j<16;j++)
		{
			byValue = GETBIT(wValue,j);
			OUTPUT_VALUE(5001 + 16*i + j,byValue);
		}
	}

	for (int i=0;i<9;i++)
	{
		safeBuf.ReadWord(wValue,HighFirst);
		for (int j=0;j<16;j++)
		{
			byValue = GETBIT(wValue,j);
			OUTPUT_VALUE(5201 + 16*i + j,byValue);
		}
	}

	return TRUE;
}
//����״̬
BOOL CYDDEMSCmd::PackCmdOnOffStatusData(ChannelList & InputChannelList, ChannelList & globalParam, BYTE * pBuf, int & nSize)
{
	return CModbusCmd::PackCmd(m_byAddrCode,0x03, 25600, 9,pBuf,nSize);
}
BOOL CYDDEMSCmd::UnPackCmdOnOffStatusData(BYTE * pBuf, int nSize,  ChannelList & OutputChannelList, ChannelList & globalParam)
{
	BYTE byAddr,byFC;
	BYTE byDataLen = 0;

	//���CRC16У��λ �� nSize ����
	if (!CModbusCmd::UnpackCmd(pBuf,nSize,byAddr,byFC,byDataLen))
	{
		return FALSE;
	}

	if (byAddr != m_byAddrCode)
	{
		return FALSE;
	}

	//��鹦����
	if(byFC != 0x03)
	{
		return FALSE;
	}

	if (byDataLen != 70)
	{
	}

	CSafeReadBufferAuto  safeBuf(pBuf+3, nSize);    //��д
	DECLARE_UNPACK_VAR;

	WORD	wValue  = 0;
	BYTE	byValue = 0;

	for (int i=0;i<9;i++)
	{
		safeBuf.ReadWord(wValue,HighFirst);
		for (int j=0;j<16;j++)
		{
			byValue = GETBIT(wValue,j);
			byValue = (byValue == 0)?1:0;	//0���� 1������
			OUTPUT_VALUE(6001 + 16*i + j,byValue);
		}
	}

	return TRUE;
}

//��ȡ�¶�1_72
BOOL CYDDEMSCmd::PackCmdTemp1_72(ChannelList & InputChannelList, ChannelList & globalParam, BYTE * pBuf, int & nSize)
{
	return CModbusCmd::PackCmd(m_byAddrCode,0x03, 4352, 72,pBuf,nSize);
}
BOOL CYDDEMSCmd::UnPackCmdTemp1_72(BYTE * pBuf, int nSize,  ChannelList & OutputChannelList, ChannelList & globalParam)
{
	BYTE byAddr,byFC;
	BYTE byDataLen = 0;

	//���CRC16У��λ �� nSize ����
	if (!CModbusCmd::UnpackCmd(pBuf,nSize,byAddr,byFC,byDataLen))
	{
		return FALSE;
	}

	if (byAddr != m_byAddrCode)
	{
		return FALSE;
	}

	//��鹦����
	if(byFC != 0x03)
	{
		return FALSE;
	}

	if (byDataLen != 72)
	{
	}

	CSafeReadBufferAuto  safeBuf(pBuf+3, nSize);    //��д
	DECLARE_UNPACK_VAR;

	WORD	wValue  = 0;
	float	fValue  = 0;

	for (int i=0;i<72;i++)
	{
		safeBuf.ReadWord(wValue,HighFirst);
		fValue = wValue * 0.1;
		OUTPUT_VALUE(30001 + i,fValue);
	}

	return TRUE;
}


//��ȡ�¶�73_144
BOOL CYDDEMSCmd::PackCmdTemp73_144(ChannelList & InputChannelList, ChannelList & globalParam, BYTE * pBuf, int & nSize)
{
	return CModbusCmd::PackCmd(m_byAddrCode,0x03, 4424, 72,pBuf,nSize);
}
BOOL CYDDEMSCmd::UnPackCmdTemp73_144(BYTE * pBuf, int nSize,  ChannelList & OutputChannelList, ChannelList & globalParam)
{
	BYTE byAddr,byFC;
	BYTE byDataLen = 0;

	//���CRC16У��λ �� nSize ����
	if (!CModbusCmd::UnpackCmd(pBuf,nSize,byAddr,byFC,byDataLen))
	{
		return FALSE;
	}

	if (byAddr != m_byAddrCode)
	{
		return FALSE;
	}

	//��鹦����
	if(byFC != 0x03)
	{
		return FALSE;
	}

	if (byDataLen != 72)
	{
	}

	CSafeReadBufferAuto  safeBuf(pBuf+3, nSize);    //��д
	DECLARE_UNPACK_VAR;

	WORD	wValue  = 0;
	float	fValue  = 0;

	for (int i=0;i<72;i++)
	{
		safeBuf.ReadWord(wValue,HighFirst);
		fValue = wValue * 0.1;
		OUTPUT_VALUE(30073 + i,fValue);
	}

	return TRUE;
}


//��ȡ֧·�����澯
BOOL CYDDEMSCmd::PackCmdCurrentAlarmData(ChannelList & InputChannelList, ChannelList & globalParam, BYTE * pBuf, int & nSize)
{
	return CModbusCmd::PackCmd(m_byAddrCode,0x03, 49187, 36,pBuf,nSize);
}
BOOL CYDDEMSCmd::UnPackCmdCurrentAlarmData(BYTE * pBuf, int nSize,  ChannelList & OutputChannelList, ChannelList & globalParam)
{
	BYTE byAddr,byFC;
	BYTE byDataLen = 0;

	//���CRC16У��λ �� nSize ����
	if (!CModbusCmd::UnpackCmd(pBuf,nSize,byAddr,byFC,byDataLen))
	{
		return FALSE;
	}

	if (byAddr != m_byAddrCode)
	{
		return FALSE;
	}

	//��鹦����
	if(byFC != 0x03)
	{
		return FALSE;
	}

	if (byDataLen != 36*2)
	{
	}

	CSafeReadBufferAuto  safeBuf(pBuf+3, nSize);    //��д
	DECLARE_UNPACK_VAR;

	WORD	wValue  = 0;
	BYTE	byValue = 0;

	for (int i=0;i<36;i++)
	{
		safeBuf.ReadWord(wValue,HighFirst);
		for (int j=0;j<16;j++)
		{
			byValue = GETBIT(wValue,j);
			OUTPUT_VALUE(7001 + 16*i + j,byValue);
		}
	}

	return TRUE;
}


//��ȡ֧·�����澯
BOOL CYDDEMSCmd::PackCmdCurrentAlarmSetting(ChannelList & InputChannelList, ChannelList & globalParam, BYTE * pBuf, int & nSize)
{
	return CModbusCmd::PackCmd(m_byAddrCode,0x03, 41028, 8,pBuf,nSize);
}
BOOL CYDDEMSCmd::UnPackCmdCurrentAlarmSetting(BYTE * pBuf, int nSize,  ChannelList & OutputChannelList, ChannelList & globalParam)
{
	BYTE byAddr,byFC;
	BYTE byDataLen = 0;

	//���CRC16У��λ �� nSize ����
	if (!CModbusCmd::UnpackCmd(pBuf,nSize,byAddr,byFC,byDataLen))
	{
		return FALSE;
	}

	if (byAddr != m_byAddrCode)
	{
		return FALSE;
	}

	//��鹦����
	if(byFC != 0x03)
	{
		return FALSE;
	}

	if (byDataLen != 8*2)
	{
	}

	CSafeReadBufferAuto  safeBuf(pBuf+3, nSize);    //��д
	DECLARE_UNPACK_VAR;

	WORD	wValueH = 0;
	WORD	wValueL = 0;
	BYTE	byValue = 0;
	FLOAT   fValue  = 0;
	DWORD   dwValue = 0;

	for (int i = 0 ; i < 4; i ++)
	{
		safeBuf.ReadWord(wValueL, HighFirst);
		safeBuf.ReadWord(wValueH, HighFirst);
		dwValue = wValueH * 0x10000 + wValueL;
		memcpy(&fValue, &dwValue, 4);
		OUTPUT_VALUE(31000 + i, fValue);
	}

	return TRUE;
}

//���ò���
BOOL	CYDDEMSCmd::PackCmdSetData(ChannelList & InputChannelList, ChannelList & globalParam, BYTE * pBuf, int & nSize)
{
	if (InputChannelList.size() < 0)
	{
		return FALSE;
	}

	WORD wPos = 0;
	WORD wValueH = 0;
	WORD wValueL = 0;
	DWORD dwValue = 0;
	FLOAT fValue = 0;
	InputChannelList[0].value.GetValue(fValue);
	BYTE  byData[512];
	CSafeWriteBufferAuto  safeBuf(byData, 512);    //��д


	switch(InputChannelList[0].dwID)
	{
	case 31000:
		wPos = 41028;
		memcpy(&dwValue, &fValue, 4);
		wValueH = dwValue / 0x10000;
		wValueL = dwValue % 0x10000;
		safeBuf.WriteWord(wValueL, HighFirst);
		safeBuf.WriteWord(wValueH, HighFirst);
		break;

	case 31001:
		wPos = 41030;
		memcpy(&dwValue, &fValue, 4);
		wValueH = dwValue / 0x10000;
		wValueL = dwValue % 0x10000;
		safeBuf.WriteWord(wValueL, HighFirst);
		safeBuf.WriteWord(wValueH, HighFirst);
		break;

	case 31002:
		wPos = 41032;
		memcpy(&dwValue, &fValue, 4);
		wValueH = dwValue / 0x10000;
		wValueL = dwValue % 0x10000;
		safeBuf.WriteWord(wValueL, HighFirst);
		safeBuf.WriteWord(wValueH, HighFirst);
		break;

	case 31003:
		wPos = 41034;
		memcpy(&dwValue, &fValue, 4);
		wValueH = dwValue / 0x10000;
		wValueL = dwValue % 0x10000;
		safeBuf.WriteWord(wValueL, HighFirst);
		safeBuf.WriteWord(wValueH, HighFirst);
		break;

	default:
		return FALSE;

	}

	return PackCmdWrite10(m_byAddrCode, 0x06, wPos, 2, 4, byData, pBuf, nSize );

}
BOOL	CYDDEMSCmd::UnPackCmdSetData(BYTE * pBuf, int nSize,  ChannelList & OutputChannelList, ChannelList & globalParam)
{
	if (nSize !=8)
	{
		return FALSE;
	}

	return  TRUE;
}

//����1г������
BOOL CYDDEMSCmd::PackCmdFirstDataHarmonic(ChannelList & InputChannelList, ChannelList & globalParam, BYTE * pBuf, int & nSize)
{
	return CModbusCmd::PackCmd(m_byAddrCode,0x03, 1414, 58,pBuf,nSize);
}
BOOL CYDDEMSCmd::UnPackCmdFirstDataHarmonic(BYTE * pBuf, int nSize,  ChannelList & OutputChannelList, ChannelList & globalParam)
{
	BYTE byAddr,byFC;
	BYTE byDataLen = 0;

	//���CRC16У��λ �� nSize ����
	if (!CModbusCmd::UnpackCmd(pBuf,nSize,byAddr,byFC,byDataLen))
	{
		return FALSE;
	}

	if (byAddr != m_byAddrCode)
	{
		return FALSE;
	}

	//��鹦����
	if(byFC != 0x03)
	{
		return FALSE;
	}

	if (byDataLen != 58*2)
	{
		return FALSE;
	}

	CSafeReadBufferAuto  safeBuf(pBuf+3, nSize);    //��д
	DECLARE_UNPACK_VAR;

	float fValue;
	DWORD dwValue=0;
	WORD wValueL=0;
	WORD wValueH=0;
	WORD wValue = 0;

	for (int i = 0 ; i < 3; i ++)	//��ѹ����
	{
		safeBuf.ReadWord(wValueL, HighFirst);
		safeBuf.ReadWord(wValueH, HighFirst);
		dwValue = wValueL + wValueH * 0x10000;
		memcpy(&fValue, &dwValue, 4);
		OUTPUT_VALUE(40000 + i, fValue);
	}

	for (int i = 0 ; i < 3; i ++)	//��������
	{
		safeBuf.ReadWord(wValueL, HighFirst);
		safeBuf.ReadWord(wValueH, HighFirst);
		dwValue = wValueL + wValueH * 0x10000;
		memcpy(&fValue, &dwValue, 4);
		OUTPUT_VALUE(40003 + i, fValue);
	}

	for (int i = 0 ; i < 3; i ++)	//���ʻ���
	{
		safeBuf.ReadWord(wValueL, HighFirst);
		safeBuf.ReadWord(wValueH, HighFirst);
		dwValue = wValueL + wValueH * 0x10000;
		memcpy(&fValue, &dwValue, 4);
		OUTPUT_VALUE(40006 + i, fValue);
	}

	safeBuf.JumpBack(4);

	for (int i = 0 ; i < 3; i ++)	//��ѹг��
	{
		safeBuf.ReadWord(wValueL, HighFirst);
		safeBuf.ReadWord(wValueH, HighFirst);
		dwValue = wValueL + wValueH * 0x10000;
		memcpy(&fValue, &dwValue, 4);
		OUTPUT_VALUE(40010 + i, fValue);
	}

	for (int i = 0 ; i < 3; i ++)	//����г��
	{
		safeBuf.ReadWord(wValueL, HighFirst);
		safeBuf.ReadWord(wValueH, HighFirst);
		dwValue = wValueL + wValueH * 0x10000;
		memcpy(&fValue, &dwValue, 4);
		OUTPUT_VALUE(40013 + i, fValue);
	}

	for (int i = 0 ; i < 3; i ++)	//����г��
	{
		safeBuf.ReadWord(wValueL, HighFirst);
		safeBuf.ReadWord(wValueH, HighFirst);
		dwValue = wValueL + wValueH * 0x10000;
		memcpy(&fValue, &dwValue, 4);
		OUTPUT_VALUE(40016 + i, fValue);
	}

	for (int i = 0 ; i < 8; i ++)	//������
	{
		safeBuf.ReadWord(wValueL, HighFirst);
		safeBuf.ReadWord(wValueH, HighFirst);
		dwValue = wValueL + wValueH * 0x10000;
		memcpy(&fValue, &dwValue, 4);
		OUTPUT_VALUE(40019 + i, fValue);
	}

	return TRUE;
}

//����2г������
BOOL CYDDEMSCmd::PackCmdSecondDataHarmonic(ChannelList & InputChannelList, ChannelList & globalParam, BYTE * pBuf, int & nSize)
{
	return CModbusCmd::PackCmd(m_byAddrCode,0x03, 1926, 58,pBuf,nSize);
}
BOOL CYDDEMSCmd::UnPackCmdSecondDataHarmonic(BYTE * pBuf, int nSize,  ChannelList & OutputChannelList, ChannelList & globalParam)
{
	BYTE byAddr,byFC;
	BYTE byDataLen = 0;

	//���CRC16У��λ �� nSize ����
	if (!CModbusCmd::UnpackCmd(pBuf,nSize,byAddr,byFC,byDataLen))
	{
		return FALSE;
	}

	if (byAddr != m_byAddrCode)
	{
		return FALSE;
	}

	//��鹦����
	if(byFC != 0x03)
	{
		return FALSE;
	}

	if (byDataLen != 58*2)
	{
		return FALSE;
	}

	CSafeReadBufferAuto  safeBuf(pBuf+3, nSize);    //��д
	DECLARE_UNPACK_VAR;

	float fValue;
	DWORD dwValue=0;
	WORD wValueL=0;
	WORD wValueH=0;
	WORD wValue = 0;

	for (int i = 0 ; i < 3; i ++)	//��ѹ����
	{
		safeBuf.ReadWord(wValueL, HighFirst);
		safeBuf.ReadWord(wValueH, HighFirst);
		dwValue = wValueL + wValueH * 0x10000;
		memcpy(&fValue, &dwValue, 4);
		OUTPUT_VALUE(41000 + i, fValue);
	}

	for (int i = 0 ; i < 3; i ++)	//��������
	{
		safeBuf.ReadWord(wValueL, HighFirst);
		safeBuf.ReadWord(wValueH, HighFirst);
		dwValue = wValueL + wValueH * 0x10000;
		memcpy(&fValue, &dwValue, 4);
		OUTPUT_VALUE(41003 + i, fValue);
	}

	for (int i = 0 ; i < 3; i ++)	//���ʻ���
	{
		safeBuf.ReadWord(wValueL, HighFirst);
		safeBuf.ReadWord(wValueH, HighFirst);
		dwValue = wValueL + wValueH * 0x10000;
		memcpy(&fValue, &dwValue, 4);
		OUTPUT_VALUE(41006 + i, fValue);
	}

	safeBuf.JumpBack(4);

	for (int i = 0 ; i < 3; i ++)	//��ѹг��
	{
		safeBuf.ReadWord(wValueL, HighFirst);
		safeBuf.ReadWord(wValueH, HighFirst);
		dwValue = wValueL + wValueH * 0x10000;
		memcpy(&fValue, &dwValue, 4);
		OUTPUT_VALUE(41010 + i, fValue);
	}

	for (int i = 0 ; i < 3; i ++)	//����г��
	{
		safeBuf.ReadWord(wValueL, HighFirst);
		safeBuf.ReadWord(wValueH, HighFirst);
		dwValue = wValueL + wValueH * 0x10000;
		memcpy(&fValue, &dwValue, 4);
		OUTPUT_VALUE(41013 + i, fValue);
	}

	for (int i = 0 ; i < 3; i ++)	//����г��
	{
		safeBuf.ReadWord(wValueL, HighFirst);
		safeBuf.ReadWord(wValueH, HighFirst);
		dwValue = wValueL + wValueH * 0x10000;
		memcpy(&fValue, &dwValue, 4);
		OUTPUT_VALUE(41016 + i, fValue);
	}

	for (int i = 0 ; i < 8; i ++)	//������
	{
		safeBuf.ReadWord(wValueL, HighFirst);
		safeBuf.ReadWord(wValueH, HighFirst);
		dwValue = wValueL + wValueH * 0x10000;
		memcpy(&fValue, &dwValue, 4);
		OUTPUT_VALUE(41019 + i, fValue);
	}

	return TRUE;
}

//��·��������
BOOL CYDDEMSCmd::PackCmdPowerPartDataALL(ChannelList & InputChannelList, ChannelList & globalParam, BYTE * pBuf, int & nSize)
{
	if (m_byNum >= 50)
	{
		m_byNum = 0;
	}
	m_byNum ++;
	return CModbusCmd::PackCmd(m_byAddrCode,0x03, 16384 + (m_byNum - 1) * 64, 39,pBuf,nSize);
}
BOOL CYDDEMSCmd::UnPackCmdPowerPartDataALL(BYTE * pBuf, int nSize,  ChannelList & OutputChannelList, ChannelList & globalParam)
{
	BYTE byAddr,byFC;
	BYTE byDataLen = 0;

	//���CRC16У��λ �� nSize ����
	if (!CModbusCmd::UnpackCmd(pBuf,nSize,byAddr,byFC,byDataLen))
	{
		return FALSE;
	}

	if (byAddr != m_byAddrCode)
	{
		return FALSE;
	}

	//��鹦����
	if(byFC != 0x03)
	{
		return FALSE;
	}

	if (byDataLen != 39*2)
	{
	}

	CSafeReadBufferAuto  safeBuf(pBuf+3, nSize);    //��д
	DECLARE_UNPACK_VAR;

	float fValue;
	DWORD dwValue=0;
	WORD wValueL=0;
	WORD wValueH=0;
	WORD wValue = 0;
	short sValue = 0;
	WORD wAdd = (m_byNum - 1);

	safeBuf.JumpBack(6 * 2);

	for (int i = 0 ; i < 2; i ++)
	{
		safeBuf.ReadWord(wValueL, HighFirst);
		safeBuf.ReadWord(wValueH, HighFirst);
		dwValue = wValueL + wValueH * 0x10000;
		memcpy(&fValue, &dwValue, 4);
		OUTPUT_VALUE(42000 + i*1000 + wAdd, fValue);
	}
	
	safeBuf.JumpBack(2*2);

	safeBuf.ReadWord(wValueL, HighFirst);
	safeBuf.ReadWord(wValueH, HighFirst);
	dwValue = wValueL + wValueH * 0x10000;
	memcpy(&fValue, &dwValue, 4);
	OUTPUT_VALUE(44000 + wAdd, fValue);

	safeBuf.ReadShort(sValue, HighFirst);
	fValue = sValue * 0.001;
	OUTPUT_VALUE(45000 + wAdd, fValue);

	safeBuf.JumpBack(16*2);

	safeBuf.ReadShort(sValue, HighFirst);
	fValue = sValue * 0.01;
	OUTPUT_VALUE(45200 + wAdd, fValue);

	for (int i = 0 ; i < 2; i ++)
	{
		safeBuf.ReadWord(wValue, HighFirst);
		fValue = wValue * 0.01;
		OUTPUT_VALUE(46000 + i*1000 + wAdd, fValue);
	}

	for (int i = 0 ; i < 2; i ++)
	{
		safeBuf.ReadWord(wValueL, HighFirst);
		safeBuf.ReadWord(wValueH, HighFirst);
		dwValue = wValueL + wValueH * 0x10000;
		memcpy(&fValue, &dwValue, 4);
		OUTPUT_VALUE(48000 + i*1000 + wAdd, fValue);
	}

	for (int i = 0 ; i < 1; i ++)
	{
		safeBuf.ReadWord(wValue, HighFirst);
		fValue = wValue * 0.01;
		OUTPUT_VALUE(50000 + i*1000 + wAdd, fValue);
	}

	return TRUE;
}


//��ȡ1·��������2
BOOL CYDDEMSCmd::PackCmdFirstPower2(ChannelList & InputChannelList, ChannelList & globalParam, BYTE * pBuf, int & nSize)
{
	return CModbusCmd::PackCmd(m_byAddrCode,0x03, 540, 70,pBuf,nSize);
}
BOOL CYDDEMSCmd::UnPackCmdFirstPower2(BYTE * pBuf, int nSize,  ChannelList & OutputChannelList, ChannelList & globalParam)
{
	BYTE byAddr,byFC;
	BYTE byDataLen = 0;

	//���CRC16У��λ �� nSize ����
	if (!CModbusCmd::UnpackCmd(pBuf,nSize,byAddr,byFC,byDataLen))
	{
		return FALSE;
	}

	if (byAddr != m_byAddrCode)
	{
		return FALSE;
	}

	//��鹦����
	if(byFC != 0x03)
	{
		return FALSE;
	}

	if (byDataLen != 70*2)
	{
		return FALSE;
	}

	CSafeReadBufferAuto  safeBuf(pBuf+3, nSize);    //��д
	DECLARE_UNPACK_VAR;

	float fValue;
	DWORD dwValue=0;
	WORD wValueL=0;
	WORD wValueH=0;
	WORD wValue = 0;

	for (int i = 0 ; i < 35; i ++)	//
	{
		safeBuf.ReadWord(wValueL, HighFirst);
		safeBuf.ReadWord(wValueH, HighFirst);
		dwValue = wValueL + wValueH * 0x10000;
		memcpy(&fValue, &dwValue, 4);
		OUTPUT_VALUE(1200 + i, fValue);
	}

	return TRUE;
}


//��ȡ2·��������2
BOOL CYDDEMSCmd::PackCmdSecondPower2(ChannelList & InputChannelList, ChannelList & globalParam, BYTE * pBuf, int & nSize)
{
	return CModbusCmd::PackCmd(m_byAddrCode,0x03, 740, 70,pBuf,nSize);
}
BOOL CYDDEMSCmd::UnPackCmdSecondPower2(BYTE * pBuf, int nSize,  ChannelList & OutputChannelList, ChannelList & globalParam)
{
	BYTE byAddr,byFC;
	BYTE byDataLen = 0;

	//���CRC16У��λ �� nSize ����
	if (!CModbusCmd::UnpackCmd(pBuf,nSize,byAddr,byFC,byDataLen))
	{
		return FALSE;
	}

	if (byAddr != m_byAddrCode)
	{
		return FALSE;
	}

	//��鹦����
	if(byFC != 0x03)
	{
		return FALSE;
	}

	if (byDataLen != 70*2)
	{
		return FALSE;
	}

	CSafeReadBufferAuto  safeBuf(pBuf+3, nSize);    //��д
	DECLARE_UNPACK_VAR;

	float fValue;
	DWORD dwValue=0;
	WORD wValueL=0;
	WORD wValueH=0;
	WORD wValue = 0;

	for (int i = 0 ; i < 35; i ++)	//
	{
		safeBuf.ReadWord(wValueL, HighFirst);
		safeBuf.ReadWord(wValueH, HighFirst);
		dwValue = wValueL + wValueH * 0x10000;
		memcpy(&fValue, &dwValue, 4);
		OUTPUT_VALUE(2200 + i, fValue);
	}

	return TRUE;
}


//��ȡ1·��������
BOOL CYDDEMSCmd::PackCmdFirstFundamental(ChannelList & InputChannelList, ChannelList & globalParam, BYTE * pBuf, int & nSize)
{
	return CModbusCmd::PackCmd(m_byAddrCode,0x03, 214, 54,pBuf,nSize);
}
BOOL CYDDEMSCmd::UnPackCmdFirstFundamental(BYTE * pBuf, int nSize,  ChannelList & OutputChannelList, ChannelList & globalParam)
{
	BYTE byAddr,byFC;
	BYTE byDataLen = 0;

	//���CRC16У��λ �� nSize ����
	if (!CModbusCmd::UnpackCmd(pBuf,nSize,byAddr,byFC,byDataLen))
	{
		return FALSE;
	}

	if (byAddr != m_byAddrCode)
	{
		return FALSE;
	}

	//��鹦����
	if(byFC != 0x03)
	{
		return FALSE;
	}

	if (byDataLen != 54*2)
	{
		return FALSE;
	}

	CSafeReadBufferAuto  safeBuf(pBuf+3, nSize);    //��д
	DECLARE_UNPACK_VAR;

	float fValue;
	DWORD dwValue=0;
	WORD wValueL=0;
	WORD wValueH=0;
	WORD wValue = 0;

	for (int i = 0 ; i < 27; i ++)	//
	{
		safeBuf.ReadWord(wValueL, HighFirst);
		safeBuf.ReadWord(wValueH, HighFirst);
		dwValue = wValueL + wValueH * 0x10000;
		memcpy(&fValue, &dwValue, 4);
		OUTPUT_VALUE(1300 + i, fValue);
	}

	return TRUE;
}


//��ȡ2·��������
BOOL CYDDEMSCmd::PackCmdSecondFundamental(ChannelList & InputChannelList, ChannelList & globalParam, BYTE * pBuf, int & nSize)
{
	return CModbusCmd::PackCmd(m_byAddrCode,0x03, 1926, 54,pBuf,nSize);
}
BOOL CYDDEMSCmd::UnPackCmdSecondFundamental(BYTE * pBuf, int nSize,  ChannelList & OutputChannelList, ChannelList & globalParam)
{
	BYTE byAddr,byFC;
	BYTE byDataLen = 0;

	//���CRC16У��λ �� nSize ����
	if (!CModbusCmd::UnpackCmd(pBuf,nSize,byAddr,byFC,byDataLen))
	{
		return FALSE;
	}

	if (byAddr != m_byAddrCode)
	{
		return FALSE;
	}

	//��鹦����
	if(byFC != 0x03)
	{
		return FALSE;
	}

	if (byDataLen != 54*2)
	{
		return FALSE;
	}

	CSafeReadBufferAuto  safeBuf(pBuf+3, nSize);    //��д
	DECLARE_UNPACK_VAR;

	float fValue;
	DWORD dwValue=0;
	WORD wValueL=0;
	WORD wValueH=0;
	WORD wValue = 0;

	for (int i = 0 ; i < 27; i ++)	//
	{
		safeBuf.ReadWord(wValueL, HighFirst);
		safeBuf.ReadWord(wValueH, HighFirst);
		dwValue = wValueL + wValueH * 0x10000;
		memcpy(&fValue, &dwValue, 4);
		OUTPUT_VALUE(1300 + i, fValue);
	}

	return TRUE;
}


//������״̬
BOOL CYDDEMSCmd::PackCmdOnOffStatusData2(ChannelList & InputChannelList, ChannelList & globalParam, BYTE * pBuf, int & nSize)
{
	return CModbusCmd::PackCmd(m_byAddrCode,0x03, 25620, 3,pBuf,nSize);
}
BOOL CYDDEMSCmd::UnPackCmdOnOffStatusData2(BYTE * pBuf, int nSize,  ChannelList & OutputChannelList, ChannelList & globalParam)
{
	BYTE byAddr,byFC;
	BYTE byDataLen = 0;

	//���CRC16У��λ �� nSize ����
	if (!CModbusCmd::UnpackCmd(pBuf,nSize,byAddr,byFC,byDataLen))
	{
		return FALSE;
	}

	if (byAddr != m_byAddrCode)
	{
		return FALSE;
	}

	//��鹦����
	if(byFC != 0x03)
	{
		return FALSE;
	}

	if (byDataLen != 3*2)
	{
		return FALSE;
	}

	CSafeReadBufferAuto  safeBuf(pBuf+3, nSize);    //��д
	DECLARE_UNPACK_VAR;

	BYTE  byBit = 0;
	WORD  wValue=0;

	safeBuf.ReadWord(wValue,HighFirst);
	for (int i = 0; i < 10;i++)
	{
		byBit = GETBIT(wValue,i);
		OUTPUT_VALUE(10100 + i,byBit);
	}

	safeBuf.ReadWord(wValue,HighFirst);
	for (int i = 0; i < 10;i++)
	{
		byBit = GETBIT(wValue,i);
		OUTPUT_VALUE(10200 + i,byBit);
	}
	
	safeBuf.ReadWord(wValue,HighFirst);
	for (int i = 0; i < 2;i++)
	{
		byBit = GETBIT(wValue,i);
		OUTPUT_VALUE(10300 + i,byBit);
	}

	return TRUE;
}
