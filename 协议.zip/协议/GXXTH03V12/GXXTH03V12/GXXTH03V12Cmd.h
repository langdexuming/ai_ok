#pragma once
#include <StdCmdBase.h>

class  CGXXTH03V12Cmd;

DECLARE_COMMAND_STRUCT(CGXXTH03V12Cmd)

class CGXXTH03V12Cmd  :public CStdCmdBase
{
public:
	CGXXTH03V12Cmd(DWORD dwID);
	~CGXXTH03V12Cmd(void);
public:


	BOOL PackCmdReadData(ChannelList & InputChannelList, ChannelList & globalParam, BYTE * pBuf, int & nSize);
	BOOL UnPackCmdReadData(BYTE * pBuf, int nSize,  ChannelList & OutputChannelList, ChannelList & globalParam);

};
