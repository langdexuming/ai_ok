#include "GXXTH03V12.h"

CProtocolConfig * CreateProtocolConfigObj()
{
	return  new  CGXXTH03V12Config();
}

CGXXTH03V12Config::CGXXTH03V12Config()
{
	InitProtocol();
	InitCommand();
	InitChannelData();
}

CGXXTH03V12Config::~CGXXTH03V12Config()
{

}


void          CGXXTH03V12Config::InitProtocol()
{
	//////////////////
	//Э��ID�Ͱ汾��//
	//////////////////
	memset(&m_ProtocolInfo, 0, sizeof(m_ProtocolInfo));
	m_ProtocolInfo.dwID = 9458;//Э��ID
	strcpy(m_ProtocolInfo.acName, "GXXTH03V12");
	m_ProtocolInfo.wType = PROTOCOLTYPE_MODBUS;//Э��Ϊmodbus
	m_ProtocolInfo.wByteCode = BYTEMODE_HIGH;

	SetVersion("4.0.1.1");  //�汾�Ų��ܼ�V

	CProtocolConfig::InitProtocol();
}

void          CGXXTH03V12Config::InitCommand()
{
	StdCmdInfo  cmdInfo;

	INIT_COMMAND(1, "��ȡ�¶�", CMDTYPE_CIRCLE,  
		&CGXXTH03V12Cmd::PackCmdReadData, 
		&CGXXTH03V12Cmd::UnPackCmdReadData);

	
	CProtocolConfig::InitCommand();

}


void          CGXXTH03V12Config::InitChannelData()
{

	INIT_AL( 1, "ͨ��״̬");//��д�����øĶ�

	INIT_YC( 20001, "�¶�");	
	INIT_YC( 20002, "ʪ��");	


	CProtocolConfig::InitChannelData();
}
